# This is a header
## This is a smaller header
### This is an even smaller header!


# This is my Project
## this is a smaller version

<br>

*Italics*
*Hello*

<br>

**Bold**

<br>

# ***Bold, Italics, and a Header***

<br>

This is an Image
=================
![Image](chrome_vGiqS64eLn.png)

<br>
This is a Link
==============
[LinkedIn](https://www.linkedin.com/in/dchicchon/)

<br>

<h1>You can still use HTML tags in markdown</h1>

<br>

# Lists
### Unordered Lists
- Item
- Item  
- Item
- item

### Ordered Lists

1. Item
2. Item
3. Item


<br>

# Tables

| Header | Header | Header |
|--------|--------|--------|
| Content| Content| Content|




