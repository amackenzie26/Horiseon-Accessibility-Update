* You can create unordered lists with the <ul> tag and elements within that list with the <li> tag.

* You can set the target of a link to be "_blank" to open that link within a new tab.

* The content between the <a> tags can be anything! Even a picture!