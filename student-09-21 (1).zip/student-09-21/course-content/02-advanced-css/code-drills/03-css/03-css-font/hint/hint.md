* Remember to link both the Google fonts and your css file

* Specify that the css file you linked is a stylesheet in relation to our html.

* Remember to declare a class or id for each of the divs!

* You can modify the format of the fonts by changing their weight or their style

* Bonus: Remember the hover pseudoclass!