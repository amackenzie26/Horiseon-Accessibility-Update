# Semantics

## Code Refactor

## Instructions
In this exercise, your task is to refactor the code by using semantics

* Open the `unsolved` folder and open `index.html` in the browser and examine the output

* Open `index.html` file and edit the existing code

* Open `style.css` file and make changes to the *css-selectors* accordingly

* There should not be any change in the output. In the event that your output changes, then re-examine your code

*Good Luck!*
