// Open up the console to see this log
console.log("Your external JavaScript file is linked 🎉");
console.log("as many as you want");
console.log("as many as you want");
console.log("as many as you want");
console.log("as many as you want");
console.log("as many as you want");
console.log("as many as you want");
