# INTERVIEW QUESTIONS

## `Index-Of`

## Instructions
Given an array and an element, find the index of that element in the array. If it does not exist in the array, return -1. If there are multiple occurences of that element in the array, return the index of first occurence

We will be recreating the native JS `indexOf` function from scratch.

## Example
Test Case 1: [1, 2, 1, 3, 2, 4, 2, 3, 3, 1, 3, 3], 3  

*Expected Output: **3***

Test Case 2: [1, 2, 3, 4], 5  

*Expected Output: **-1***
