var one = 64;
var two = "656302";
var three = false;
var four = 64.55;
var five = "Howdy!";
var six;

//Insert comments to explain what each console log below will log to the console
// Logs number
console.log(typeof one); 

// Logs string
console.log(typeof two); 

// Logs boolean
console.log(typeof three); 

// Logs number
console.log(typeof four); 

// Logs string
console.log(typeof five);

// Logs undefined
console.log(typeof six);

// Reassigns variables
four = "Hello!";
five = false;
six = 23;

// Insert comments to explain what each console log below will log to the console
// Logs string
console.log(typeof four);

// Logs boolean
console.log(typeof five);

// Logs number
console.log(typeof six);

var numOne = 2;
var numTwo = "2";



console.log(numOne + numTwo);//22!?!

console.log(numOne + parseInt(numTwo));//4!
    
