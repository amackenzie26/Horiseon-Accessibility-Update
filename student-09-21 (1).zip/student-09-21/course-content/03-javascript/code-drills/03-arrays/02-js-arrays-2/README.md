# Javascript

## Loops

### Instructions

1. Navigate to challenge-prompt.js and follow the insturctions therein.