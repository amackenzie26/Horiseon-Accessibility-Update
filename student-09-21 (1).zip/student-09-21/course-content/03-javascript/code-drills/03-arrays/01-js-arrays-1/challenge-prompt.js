// Working with Arrays




// Create an array containing the integers from 0 to 3 and store it into a variable named `firstArray`

// Create an array containing the integers from 4 to 7 and store it into a variable named `secondArray`

// Create an array containing the integers from 8 to 11 and store it into a variable named `thirdArray`

// Create an array containing the integers from 12 to 15 and store it into a variable named `fourthArray`


// ------------------------------------------------
console.log("============ firstArray ============")
//
// Console log `firstArray`

// Individually console log the elements within `firstArray`
// Write 4 console logs, 1 for each element






// -------------------------------------------------
console.log("============ secondArray ============")
//
// Console log `secondArray`


// Individually console log the elements within `secondArray`
// Write 4 console logs, 1 for each element






// ------------------------------------------------
console.log("============ thirdArray ============")
//
// Console log `thirdArray`


// Individually console log the elements within `thirdArray`
// Write 4 console logs, 1 for each element






// -------------------------------------------------
console.log("============ fourthArray ============")
//
// Console log `fourthArray`


// Individually console log the elements within `fourthArray`
// Write 4 console logs, 1 for each element





