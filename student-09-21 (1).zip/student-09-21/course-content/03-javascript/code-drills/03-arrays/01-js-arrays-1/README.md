# Javascript

## Arrays

### Instructions

- Open up `challenge-prompt.js` and follow the instructions there
- make sure you check the console in the browser to see the result!
