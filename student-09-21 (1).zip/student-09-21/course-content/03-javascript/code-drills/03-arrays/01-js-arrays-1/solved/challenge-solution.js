// Working with Arrays



// Create an array containing the integers from 0 to 3 and store it into a variable named `firstArray`
var firstArray = [0, 1, 2, 3];
// Create an array containing the integers from 4 to 7 and store it into a variable named `secondArray`
var secondArray = [4, 5, 6, 7];
// Create an array containing the integers from 8 to 11 and store it into a variable named `thirdArray`
var thirdArray = [8, 9, 10, 11];
// Create an array containing the integers from 12 to 15 and store it into a variable named `fourthArray`
var fourthArray = [12, 13, 14, 15];

// ------------------------------------------------
console.log("============ firstArray ============")
//
// Console log `firstArray`
console.log(firstArray)
// Individually console log the elements within `firstArray`
// Write 4 console logs, 1 for each element
console.log(firstArray[0])
console.log(firstArray[1])
console.log(firstArray[2])
console.log(firstArray[3])


// -------------------------------------------------
console.log("============ secondArray ============")
//
// Console log `secondArray`
console.log(secondArray)
// Individually console log the elements within `secondArray`
// Write 4 console logs, 1 for each element
console.log(secondArray[0])
console.log(secondArray[1])
console.log(secondArray[2])
console.log(secondArray[3])


// ------------------------------------------------
console.log("============ thirdArray ============")
//
// Console log `thirdArray`
console.log(thirdArray)
// Individually console log the elements within `thirdArray`
// Write 4 console logs, 1 for each element
console.log(thirdArray[0])
console.log(thirdArray[1])
console.log(thirdArray[2])
console.log(thirdArray[3])


// -------------------------------------------------
console.log("============ fourthArray ============")
//
// Console log `fourthArray`
console.log(fourthArray)
// Individually console log the elements within `fourthArray`
// Write 4 console logs, 1 for each element
console.log(fourthArray[0])
console.log(fourthArray[1])
console.log(fourthArray[2])
console.log(fourthArray[3])
