* Store the user response in a variable to be accessed later
    * remember to declare this variable outside of the callback function you pass to your event listener

* You can use an `if` statement within an event listener to change the behavior of a button press

* The attached javascript file contains pseudo code for you to follow if you want more guidance
