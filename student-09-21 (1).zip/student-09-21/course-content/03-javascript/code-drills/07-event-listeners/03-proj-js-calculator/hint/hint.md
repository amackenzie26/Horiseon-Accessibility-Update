* The previous activity walks you through input validation and storing input

* You can check if an operator is already present in the array you're storing or use a boolean to keep track of whether the user has inputted an operator

* You'll have to iterate through the user input in order to construct the numbers
    * the numbers are seperated by one of the mathematical operators

* You will need multiple if statements in order to handle discovering which operator the user defined

* You do not need to store the `=` key or the `c` key into your expression

* When you clear the output, remember to also clear the expression array

* The attached html and javascript file contains pseudo code for you to follow if you want more guidance
