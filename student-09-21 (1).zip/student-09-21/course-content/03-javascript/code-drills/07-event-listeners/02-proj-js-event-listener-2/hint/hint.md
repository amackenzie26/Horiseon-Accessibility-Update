* Store the user response in a variable to be accessed later
    * remember to declare this variable outside of the callback function you pass to your event listener

* You might have to create an array of all the valid inputs

* You can use an `if` statement within an event listener to check if the user has given a valid input

* You should only be adding an input to the array if the input is valid, which means putting that logic inside your `if` statement

* The attached html and javascript file contains pseudo code for you to follow if you want more guidance
