# Algorithms

## 99 Bottles of beer

🎵
99 bottles of beer on the wall, 99 bottles of beer. You take one down, pass it around, 98 bottles of beer on the wall. 
98 bottles of beer on the wall, 98 bottles of beer. You take one down, pass it around, 97 bottles of beer on the wall. 
🎵

## Instructions

You know the song! Before cell phones, people had to pass time by singing songs like this one. Now we have technology, so we can just make our computers do it. 

Navigate to prompt.html and within the designated space, write a function that sings the song until its conclusion.

When you are down to your last bottle, your function should write "1 bottle of beer on the wall, 1 bottle of beer. Take one down, pass it around, no more bottles of beer on the wall!"