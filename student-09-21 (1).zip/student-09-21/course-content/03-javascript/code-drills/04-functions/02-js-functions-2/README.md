# Javascript

## Returns

_By including a return value, we can have functions build upon each other. We can use those return values elsewhere in our code. Otherwise, we can't refer to values created within functions outside of them. We've provided an html already linked to the javascript file that you can open to see your console logs and alerts._

### Instructions

1. Navigate to challenge-prompt.js and follow the insturctions therein.