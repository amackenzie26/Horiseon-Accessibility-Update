* A return value is not automatically console logged. If you wish to console log the return value of a function, you will have to console log the result of calling that function.

* If a function has a return value, you can store that return value into a variable when you call it.
