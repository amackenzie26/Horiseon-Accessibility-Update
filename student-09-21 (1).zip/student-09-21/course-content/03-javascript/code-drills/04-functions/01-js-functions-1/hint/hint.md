* If you've defined a function

    > function test() {}

    You can call that function by invoking its name followed by parenthesis

    > test()

* You can store the value of a `confirm` or `prompt` dialogue into a variable

* When you need to refer to an argument that you pass into your function, it will have whatever name is given to it during your function definition
    ```
    function argTest(argument1, testArg, anything) {
          console.log(argument1);
          console.log(testArg);
          console.log(anything)
        }
    ```
