# Javascript

## Functions

_Functions are a great way to wrap chunks of code so you can use it later. Functions take in an argument and does work on that argument. If you `return` a value, then we can use that value when we call the function. Remember, after you define a function, you have to call the function in order to actually execute its contents. We've provided an html already linked to the javascript file that you can open to see your console logs and alerts._

### Instructions

1. Navigate to challenge-prompt.js and follow the insturctions therein.
