# Javascript

## Variabes

_You will be getting practice declaring and manipulating variables in this exercise._

### Instructions

- Open up `challenge-prompt.js` and follow the instructions there
- make sure you check the console in the browser to see the result!