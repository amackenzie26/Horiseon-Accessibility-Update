// check out document.wirte to write on the page
// also check if question is true