# Javascript

## User Feedback and Writing to the DOM

### Instructions

- Open up `challenge-prompt.js` and follow the instructions there
