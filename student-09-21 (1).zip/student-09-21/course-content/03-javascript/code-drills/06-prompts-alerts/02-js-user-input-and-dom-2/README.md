# Javascript

## User Feedback and Writing to the DOM pt. 2

### Instructions

- Open up `challenge-prompt.js` and follow the instructions there
