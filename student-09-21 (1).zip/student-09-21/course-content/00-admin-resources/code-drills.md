# Code Drills
[Back to Course Guidelines](../../README.md#course-guidelines)

### Code Drills Completion Minimum

Please see each `Code Drill` resource for each Module. 

Code Drills are expected to be completed incrementally.

Code Drills are a way of getting practice of concepts applied in-class. 
