# Optiobnal Breakouts

## Overview


An optional survey of a variety of techincal topics. 